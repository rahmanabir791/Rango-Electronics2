
<div class="row align-items-center py-3 px-xl-5">
    <div class="col-lg-3 d-none d-lg-block">
        <a href="" class="text-decoration-none">
            <img style="width: 170px; left: 15px;" src="<?php echo e(asset('/')); ?>assets/front-asset/img/rongo.png" alt="">
        </a>
    </div>
    <div class="col-lg-6 col-6 text-left">
        <form action="">
            <div class="input-group">
                <input type="text" class="form-control" placeholder="Search for products">
                <div class="input-group-append">
                            <span class="input-group-text bg-transparent text-primary">
                                <i class="fa fa-search"></i>
                            </span>
                </div>
            </div>
        </form>
    </div>
    <div class="col-lg-3 col-6 text-left" style="height: 70px;">
        <a href="" class="">
            <i class="fa-solid fa-user text-dark"></i>
        </a>
        <a href="" class="col-lg-3 col-6 text-left" style="height: 70px">
            <i class="fas fa-shopping-cart text-dark"></i>
        </a>
    </div>
</div>
</div>
<?php /**PATH D:\My work\Rango\resources\views/home/includes/tobarTwo.blade.php ENDPATH**/ ?>