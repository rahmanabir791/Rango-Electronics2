<?php $__env->startSection('title'); ?>
    ADD & Manage Brand
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="main-panel">

        <div class="content-wrapper">

            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Add Brand</h4>
                        <p class="card-description">Select the category name, brand name, and upload an image for the brand</p>
                        <form method="post" action="<?php echo e(route('new-Brands')); ?>" class="form-inline" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <label class="sr-only" for="categoryName">Category Name</label>
                            <select class="form-control mb-2 mr-sm-2" name="category_id" aria-label="Default select example" required>
                                <option selected disabled>Open this select Product Category</option>
                                <?php $__currentLoopData = $allCategorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($allCategory->id); ?>"><?php echo e($allCategory->CategoryName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <label class="sr-only" for="brandName">Brand Name</label>
                            <input type="text" name="BrandName" class="form-control mb-2 mr-sm-2" id="brandName" placeholder="Brand Name" required>

                            <div class="input-group mb-2 mr-sm-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">Brand Image  {height: 350px;  width:250px;}</div>
                                </div>
                                <input type="file" name="BrandImage" class="form-control" id="brandImage" accept="image/*" >
                            </div>

                            <button type="submit" class="btn btn-gradient-primary mb-2">Add brands to categories</button>
                        </form>
                    </div>
                </div>
            </div>


            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">All Slider Details</h4>

                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Brands Name</th>
                            <th>Brands Image</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                            $brandCategories = [];
                            $currentCategory = null;

                            foreach ($newBrands as $newBrand) {
                                $brandCategories[$newBrand->category_id][] = $newBrand;
                            }
                        ?>

                        <?php $__currentLoopData = $allCategorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $brandsInCategory = isset($brandCategories[$category->id]) ? $brandCategories[$category->id] : [];
                            ?>

                            <?php if(!empty($brandsInCategory)): ?>
                                <?php if($currentCategory != $category->CategoryName): ?>
                                    <?php
                                        $currentCategory = $category->CategoryName;
                                    ?>
                                    <tr>
                                        <td colspan="4">
                                            <h3><?php echo e($currentCategory); ?></h3>
                                        </td>
                                    </tr>
                                <?php endif; ?>

                                <?php $__currentLoopData = $brandsInCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newBrand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($newBrand->BrandName); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset($newBrand->BrandImage)); ?>" alt="brand_image" style="height: 100px; width: 100px">
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('edit-Brands', ['id' => $newBrand->id])); ?>" class="btn btn-sm btn-secondary btn-outline-info">Edit</a>
                                            <br>
                                            <a href="<?php echo e(route('delete-brands', ['id' => $newBrand->id])); ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this Brand?')">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmanabir/Desktop/Project/Rango/resources/views/back/pages/brands/Add_manageBrands.blade.php ENDPATH**/ ?>