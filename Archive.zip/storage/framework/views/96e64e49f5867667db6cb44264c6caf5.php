<!-- partial:partials/_footer.html -->
<footer class="footer">
    <div class="container-fluid d-flex justify-content-between">
        <a href="https://rrcabir.com/"><span class="text-muted d-block text-center text-sm-start d-sm-inline-block">Copyright © AN Universe</span></a>
        <span class="float-none float-sm-end mt-1 mt-sm-0 text-end">  <a href="https://rrcabir.com/" target="_blank">AN Universe admin template</a> </span>
    </div>
</footer>
<!-- partial -->
<?php /**PATH /Users/rahmanabir/Desktop/Rango All Work/Rango/resources/views/back/include/footer.blade.php ENDPATH**/ ?>