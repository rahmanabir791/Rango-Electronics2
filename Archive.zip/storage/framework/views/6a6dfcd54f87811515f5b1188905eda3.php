<style>
    /* Hide overflow and set max-height */
    .navCategory {
        top: 0;
        bottom: 0;
        background: rgb(247, 248, 250);

    }
    nav ul {
        position: relative;
        list-style: none;
        padding: 0;
        margin: 0;
    }
    nav ul li {
        position: relative;
        display: block;

    }
    nav ul {
        position: relative;
        list-style: none;
        padding: 0;
        margin: 0;
        z-index: 1000;
    }

    nav ul li {
        position: relative;
        display: block;
        z-index: 1000;
    }

    nav ul li a {
        display: flex;
        align-items: center;
        font-size: 1.15em;
        text-decoration: none;
        text-transform: capitalize;
        color: black;
        padding: 10px 15px;
        height: 50px;
        transition: background 0.5s ease;
        z-index: 1000;
    }

    nav ul li a:hover {
        background: rgb(225, 226, 230);
        color: black;
        z-index: 1000;
    }

    nav ul ul {
        position: absolute;
        left: 100%;
        top: 0;
        display: none;
        width: 200px;
        background: rgb(247, 248, 250);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
        z-index: 1000;
    }

    nav ul .dropdown:hover > ul,
    nav ul .dropdown_two:hover > ul {
        display: block;
        z-index: 1000;
    }

    nav ul .dropdown,
    nav ul .dropdown_two {
        position: relative;
        z-index: 1000;
    }
    .navbar{
        z-index: 100;

    }
    nav ul span {
        position: absolute;
        right: 20px;
        font-size: 1.5rem;
        top: 50%;
        transform: translateY(-50%);
</style>

<div class="container-fluid" style="max-width: 100%;">
    <div class="row border-top">
        <div class="col-lg-3 col-md-4 d-none d-md-block" style="background-color: maroon;" >
            <!-- ... Existing code ... -->
            <a class="btn shadow-none d-flex align-items-center justify-content-between  w-100" data-toggle="collapse"  href="#navbar-vertical" style="height: 65px; margin-top: -1px; padding: 0 30px;">
                <h4 class="m-0" style="color: gold">Categories</h4>
            </a>
        </div>
        <div class="col-lg-9 col-md-8" style="background-color: maroon;">
            <!-- ... Existing content ... -->

            <!-- Add Bootstrap CSS -->


            <!-- Add jQuery -->
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

            <!-- Add Bootstrap JavaScript -->
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

            <nav class="navbar navbar-expand-lg navbar-light py-3 py-lg-0 px-0" style="background-color: maroon;">
                <!-- ... Existing code ... -->
                <a href="" class="text-decoration-none d-block d-md-none">
                    <h1 class="m-0 display-5 ">Menu</h1>
                </a>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon "></span>
                </button>
                <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                    <div class="navbar-nav mr-auto py-0">
                        <a href="<?php echo e(route('home')); ?>" class="nav-item nav-link active" style="color: gold; font-weight: bold; margin-left: 50px;">Home</a>
                        <a href="<?php echo e(route('All-Brands')); ?>" class="nav-item nav-link" style="color: gold; font-weight: bold; margin-left: 50px;">Brands</a>
                        <a href="<?php echo e(route('menu.installation')); ?>" class="nav-item nav-link" style="color: gold; font-weight: bold; margin-left: 50px;">Installation & Services</a>
                        <a href="<?php echo e(route('menu.contact')); ?>" class="nav-item nav-link" style="color: gold; font-weight: bold; margin-left: 50px;">Contact</a>
                    </div>
                </div>

                <a href="" class="text-decoration-none d-block d-md-none">
                    <h1 class="m-0 display-5 font-weight-semi-bold">Categories</h1>
                </a>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbar-vertical2">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </nav>

            <!-- ... Existing content ... -->
            <nav class="collapse navbar navbar-vertical navbar-light align-items-start p-0 border border-top-0 border-bottom-0" id="navbar-vertical2" >
                <div class="navbar-nav w-100 overflow">
                    <!-- ... Existing category links ... -->
                    <ul class="navbar-nav">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item dropdown" >
                                <a class="nav-link dropdown-toggle" href="#" id="categoryDropdown<?php echo e($category->id); ?>" data-toggle="dropdown">
                                    <?php echo e($category->CategoryName); ?>

                                </a>
                                <div class="dropdown-menu">
                                    
                                    <?php
                                        $categoryBrands = $brands->where('category_id', $category->id);
                                    ?>
                                    <?php $__currentLoopData = $categoryBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="dropdown-item" href="<?php echo e(route('category.wise.brand', ['id' => $brand->id])); ?>"><?php echo e($brand->BrandName); ?></a>
                                        
                                        <ul class="dropdown-menu">
                                            <?php
                                                $sameTypeIds = [];
                                            ?>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($product->category_id == $category->id && $product->brand_id == $brand->id): ?>
                                                    <?php if(!array_key_exists($product->product_type, $sameTypeIds)): ?>
                                                        <?php
                                                            $sameTypeIds[$product->product_type] = [];
                                                        ?>
                                                    <?php endif; ?>
                                                    <?php
                                                        $sameTypeIds[$product->product_type][] = $product->id;
                                                    ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $sameTypeIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productType => $ids): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="nav-item dropdown">
                                                    <a class="nav-link dropdown-toggle" href="#" id="productTypeDropdown<?php echo e($productType); ?>" data-toggle="dropdown">
                                                        <?php echo e($productType); ?>

                                                    </a>
                                                    <div class="dropdown-menu">
                                                        <?php $__currentLoopData = $ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <a class="dropdown-item" href="<?php echo e(route('type.of.product', ['ids' => implode(',', $ids)])); ?>">Product ID: <?php echo e($productId); ?></a>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </nav>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-lg-2 d-none d-md-block px-1 mt-1">
            <nav class="collapse show navbar navbar-vertical navbar-light align-items-start p-0 border border-top-0 border-bottom-0" id="navbar-vertical">
                <div class="navbar-nav w-100 overflow" >
                    <!-- ... Existing category links ... -->
                    <ul class="border" style="font-size: 10px; font-weight: bold;" >
                        
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="dropdown border"><a href="<?php echo e(route('Category-All', ['id' => $category->id])); ?>"><?php echo e($category->CategoryName); ?><span>&rsaquo;</span></a>
                                <ul>
                                    
                                    <?php
                                        $categoryBrands = $brands->where('category_id', $category->id);
                                    ?>

                                    <?php $__currentLoopData = $categoryBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="dropdown_two border"><a href="<?php echo e(route('category.wise.brand', ['id' => $brand->id])); ?>"><?php echo e($brand->BrandName); ?><span>&rsaquo;</span></a>
                                            <ul>
                                                
                                                <?php
                                                    $sameTypeIds = [];
                                                ?>

                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($product->category_id == $category->id && $product->brand_id == $brand->id): ?>
                                                        <?php if(!array_key_exists($product->product_type, $sameTypeIds)): ?>
                                                            <?php
                                                                $sameTypeIds[$product->product_type] = [];
                                                            ?>
                                                        <?php endif; ?>
                                                        <?php
                                                            $sameTypeIds[$product->product_type][] = $product->id;
                                                        ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <?php $__currentLoopData = $sameTypeIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productType => $ids): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="border">
                                                        <a href="<?php echo e(route('type.of.product', ['ids' => implode(',', $ids)])); ?>"><?php echo e($productType); ?></a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </ul>
                </div>
            </nav>
        </div>
        <div class="col-lg-10 px-1 mt-1" >
            <div class="row" >
                <div class="col-lg-9 px-2 mt-1" >
                    <div id="header-carousel" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner" style="height: 410px; border-radius: 20px;">
                            <!-- ... Existing carousel items ... -->
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>" style="border-radius: 20px;">
                                    <img class="img-fluid" src="<?php echo e(asset($slider->slidImage)); ?>" style="border-radius: 20px; height: 410px;"  alt="Image">
                                    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center" style="padding: 15px;">
                                        <div class="p-3" style="max-width: 700px; border-radius: 50px;">
                                            <h4 class="text-light text-uppercase font-weight-medium mb-3"><?php echo e($slider->sliderStext); ?></h4>
                                            <h3 class="display-4 text-white font-weight-semi-bold mb-4"><?php echo e($slider->sliderBtext); ?></h3>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- ... Existing carousel controls ... -->
                        <a class="carousel-control-prev" href="#header-carousel" data-slide="prev">
                            <div class="btn btn-dark" style="width: 45px; height: 45px;">
                                <span class="carousel-control-prev-icon mb-n2"></span>
                            </div>
                        </a>
                        <a class="carousel-control-next" href="#header-carousel" data-slide="next">
                            <div class="btn btn-dark" style="width: 45px; height: 45px;">
                                <span class="carousel-control-next-icon mb-n2"></span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-3  mt-1">
                    <!-- ... Empty column ... -->
                    <img src="<?php echo e(asset('/')); ?>assets/front-asset/img/3.png" alt="" class="img-fluid d-none d-lg-block px-0 " style="height: 200px; width: 600px;  border-radius: 20px; margin-bottom: 10px; ">
                    <img src="<?php echo e(asset('/')); ?>assets/front-asset/img/4.png" alt="" class="img-fluid d-none d-lg-block px-0" style="height: 200px; width: 600px; border-radius: 20px;">
                </div>

                    <div class="col-lg-12 px-1 mt-1">
                        <img src="<?php echo e(asset('/')); ?>assets/front-asset/img/Sliderdown.png" alt="" class="img-fluid d-none d-lg-block px-3" style="border-radius: 40px; height: 150px; width: 1150px;">
                    </div>

            </div>
        </div>
    </div>
    <!-- ad3 -->


</div>
<!-- Add the following script at the end of your HTML, just before the closing </body> tag -->


<!-- JavaScript using jQuery -->
<script>
    $(document).ready(function() {
        // Function to close the mobile menus
        function closeMobileMenus() {
            $(".navbar-collapse.show").removeClass("show");
        }

        // Toggle the first menu
        $("#navbarCollapse button.navbar-toggler").click(function() {
            closeMobileMenus();
        });

        // Toggle the second menu
        $("#navbar-vertical2 button.navbar-toggler").click(function() {
            closeMobileMenus();
        });

        // Close the menus when clicking outside of them
        $(document).on("click touchstart", function(event) {
            if (!$(event.target).closest(".navbar-collapse").length && !$(event.target).closest(".navbar-toggler").length) {
                closeMobileMenus();
            }
        });

        // Prevent menu click from closing itself
        $(".navbar-collapse").click(function(event){
            event.stopPropagation();
        });
    });

</script>


<?php /**PATH /Users/rahmanabir/Desktop/Project/Rango/resources/views/front/pages/home/navtest.blade.php ENDPATH**/ ?>