<?php echo $__env->make('home.includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

<!-- Topbar Start -->
<?php echo $__env->make('home.includes.topbarOne', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('home.includes.tobarTwo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!-- Navbar Start -->


<!-- Navbar End -->


<?php echo $__env->yieldContent('body'); ?>

<!-- Footer Start -->

<!-- Footer End -->

<?php echo $__env->make('home.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Users/rahmanabir/Desktop/Rango/resources/views/home/master.blade.php ENDPATH**/ ?>