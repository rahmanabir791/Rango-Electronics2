<style>
    /* Add this style block to your HTML or external CSS file */
    .sticky-nav {
        position: sticky;
        top: 0;
        z-index: 1000;

    }

    /* Additional styles for mobile responsiveness */
    @media (max-width: 767px) {
        .sticky-nav .col-lg-3,
        .sticky-nav .col-lg-6,
        .sticky-nav .col-lg-3 {
            padding: 0;
            margin: 0;
            text-align: center;

        }

        .sticky-nav .col-lg-3 img,
        .sticky-nav .col-lg-6 form,
        .sticky-nav .col-lg-3 {
            display: inline-block;
            vertical-align: middle;

        }

        .sticky-nav .input-group-append {
            display: flex;
            align-items: center;
        }

        .sticky-nav .row {
            padding: 8px 15px;
            margin-left: 0;
            margin-right: 0;

        }

        .sticky-nav .col-lg-6 input {
            width: 100%;

        }

        .sticky-nav .col-6 {
            text-align: left;
        }

        .sticky-nav .col-6:last-child {
            text-align: right;

        }
    }
</style>


    <nav class="sticky-nav" >
        <div class="mt-1 row col-lg-12  align-items-center" style="background-color: #800000;" >
            <div class="col-lg-3 col-6">
                <!-- Logo and Branding -->
                <div class="d-flex justify-content-start align-items-center">
                    <a href="#" class="text-decoration-none">
                        <img style="max-width: 100%; " src="<?php echo e(asset('/')); ?>assets/front-asset/img/rongologo.png" alt="Rongo Logo">
                    </a>
                    <a href="#" class="text-decoration-none ml-2">
                        <img style="max-width: 100%;" src="<?php echo e(asset('/')); ?>assets/front-asset/img/rongotext.png" alt="Rongo Text">
                    </a>
                </div>
            </div>
            <div class="col-lg-7 col-6">
                <!-- Search Form -->
                <form class="form-inline" action="">
                    <div class="input-group w-100">
                        <input type="text" class="form-control" placeholder="Search for products">
                        <div class="input-group-append">
                            <button class="btn bg-danger" type="button">
                                <i class="fa fa-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-lg-2 col-12">
                <!-- Navigation Icons and Toggle Button -->
                <div class="d-flex justify-content-center align-items-center">
                    <a href="#" class="text-decoration-none pr-3">
                        <i class="fa-solid fa-user"></i>
                    </a>
                    <a href="#" class="text-decoration-none pr-3">
                        <i class="fas fa-shopping-cart"> 1</i>
                    </a>

                </div>
            </div>
        </div>
    </nav>

<br>
<?php /**PATH /Users/rahmanabir/Desktop/Rango/resources/views/home/includes/tobarTwo.blade.php ENDPATH**/ ?>