<?php $__env->startSection('title'); ?>
    Check Out
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <style>
        .notification-banner {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            text-align: center;
            font-size: 16px;
        }
    </style>
    <?php if(session('success')): ?>
        <div class="notification-banner">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <link href="<?php echo e(asset('/')); ?>assets/front-asset/css/checkout.css" rel="stylesheet">
    <div class="container-fluid mt-5 text-center">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <h2 class="mb-4">Checkout</h2>
                <h5 class="mb-3 animate__animated animate__fadeIn">Order Summary</h5>
                <div class="data-input-form">
                    <form action="<?php echo e(route('check.out.submit')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>


                    <!-- Loop through cart items -->
                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cart-item animate__animated animate__fadeInUp">
                        <img src="<?php echo e($item->attributes->image); ?>" alt="Thumbnail" class="img-thumbnail">
                        <div class="cart-item-details">
                            <p class="cart-item-name"><?php echo e($item->name); ?></p>
                            <input type="hidden" name="products[<?php echo e($index); ?>][name]" value="<?php echo e($item->name); ?>">
                            <label for="quantity">Product Quantity: <?php echo e($item->quantity); ?></label>
                            <input type="hidden" name="products[<?php echo e($index); ?>][quantity]" value="<?php echo e($item->quantity); ?>">
                            <label for="price">Price: ৳<?php echo e(number_format($item->price)); ?></label>
                            <input type="hidden" name="products[<?php echo e($index); ?>][price]" value="<?php echo e($item->price); ?>">
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                <!-- Form input section with collected item data -->

                        <!-- Total amount display -->
                        <h4 class="cart-item-price" style="background-color: maroon; color: gold">Total Amount: ৳<?php echo e(number_format(Cart::getTotal())); ?></h4>
                        <input type="hidden" value="<?php echo e(Cart::getTotal()); ?>" name="totalAmount">

                        <!-- Payment method selection -->
                        <div class="form-group">
                            <label>Payment Method</label>
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input type="radio" class="form-check-input" name="p_status" id="cash" value="1" checked>
                                    Pay cash directly
                                </label>
                            </div>
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input type="radio" class="form-check-input" name="p_status" id="advancePaymentOnline" value="0">
                                    Pay in advance online
                                </label>
                            </div>
                        </div>

                    
                    <div id="onlinePaymentSection" style="display: none;">
                            <h4 class="cart-item-price" style="background-color: maroon; color: gold">After Advance Payment Remaining Amount: <label for="remaining_amount" id="remaining_label">৳<?php echo e(number_format(Cart::getTotal())); ?></label></h4>
                            <input type="hidden" name="remainAmount" id="remainAmount" value="">
                            <h4>For Advance Payment Make Payment This number</h4>
                            <h5 style="color: maroon">01800000000</h5>

                            <div class="form-group">
                                <label for="name">Advance Payment Amount</label>
                                <input type="number" class="form-control" id="A_payment" name="A_payment" step="0.01" min="0" oninput="calculateRemainingAmount()">
                            </div>

                            <div class="form-group">
                                <label for="name">Mobile Financial service Provider Name</label>
                                <input type="text" class="form-control" id="f_service" name="f_service">
                            </div>

                            <div class="form-group">
                                <label for="name">Transaction Number</label>
                                <input type="text" class="form-control" id="Transaction_num" name="Transaction_num">
                            </div>
                        </div>
                        
                  <div >
                      <hr style="background-color: gold; height: 3px;">
                      <hr style="background-color: gold; height: 5px; width: 350px">
                      <hr style="background-color: gold; height: 3px;">
                  </div>

                        <!-- Repeat for other cart items -->
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>

                        <div class="form-group">
                            <label for="name">Email</label>
                            <input type="text" class="form-control" id="email" name="email" required>
                        </div>

                        <div class="form-group">
                            <label for="name">Phone Number</label>
                            <input type="text" class="form-control" id="phone" name="phone" required>
                        </div>
                        <div class="form-group">
                            <label for="city">City</label>
                            <input type="text" class="form-control" id="city" name="city" required>
                        </div>
                        <div class="form-group">
                            <label for="zip">ZIP Code</label>
                            <input type="text" class="form-control" id="zip" name="zip" required>
                        </div>
                        <div class="form-group">
                            <label for="name">Address</label>
                            <textarea name="address" class="form-control" id="" cols="10" rows="3"></textarea>
                        </div>
                    <!-- Rest of the form fields -->
                    <div class="text-center mt-3">
                        <button type="submit" class="btn btn-primary checkout-btn animate__animated animate__fadeIn">Place Order</button>
                        <br>
                        <br>
                        <br>
                    </div>
                </form>
                <a href="<?php echo e(route('home')); ?>" class="continue-shopping-link animate__animated animate__fadeIn">Continue Shopping</a>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var remainingInput = document.getElementById("A_payment");
            var remainAmountInput = document.getElementById("remainAmount");
            var remainingLabel = document.getElementById("remaining_label");

            remainingInput.addEventListener("input", function() {
                calculateRemainingAmount(); // Recalculate remaining amount on input change
            });

            function calculateRemainingAmount() {
                var totalAmount = <?php echo e(Cart::getTotal()); ?>;
                var advancePayment = parseFloat(remainingInput.value);

                // Handle the case where the input is empty or NaN
                if (isNaN(advancePayment)) {
                    advancePayment = 0;
                }

                var remainingAmount = totalAmount - advancePayment;

                remainingLabel.textContent = " ৳" + remainingAmount.toFixed(2);
                remainAmountInput.value = remainingAmount.toFixed(2); // Set the input value

                return remainingAmount.toFixed(2); // Return the remaining amount
            }
        });


        document.addEventListener("DOMContentLoaded", function() {
            var onlinePaymentSection = document.getElementById("onlinePaymentSection");
            var paymentRadio = document.querySelectorAll('input[name="p_status"]');

            // Add event listeners to radio buttons
            for (var i = 0; i < paymentRadio.length; i++) {
                paymentRadio[i].addEventListener("change", function() {
                    toggleOnlinePayment(this.value);
                });
            }

            function toggleOnlinePayment(paymentValue) {
                if (paymentValue === "0") {
                    onlinePaymentSection.style.display = "block";
                } else {
                    onlinePaymentSection.style.display = "none";
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmanabir/Desktop/Rango All Work/Rango/resources/views/front/pages/cart/checkout.blade.php ENDPATH**/ ?>