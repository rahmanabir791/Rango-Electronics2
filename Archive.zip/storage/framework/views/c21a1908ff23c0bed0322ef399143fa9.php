<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <!-- partial -->

    <div class="main-panel">
        <div class="content-wrapper">
            <div class="page-header">
                <h3 class="page-title">
                <span class="page-title-icon bg-gradient-primary text-white me-2">
                  <i class="mdi mdi-home"></i>
                </span> Dashboard
                </h3>
                <nav aria-label="breadcrumb">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item active" aria-current="page">
                            <span></span>Overview <i class="mdi mdi-alert-circle-outline icon-sm text-primary align-middle"></i>
                        </li>
                    </ul>
                </nav>
            </div>

            <div class="row">
                <div class="col-12 grid-margin">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Clients Orders Cash on delivery</h4>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th> Sl NO. </th>
                                        <th> Name </th>
                                        <th> Products </th>
                                        <th> Total Amount </th>
                                        <th> Address </th>
                                        <th> Mobile NO </th>
                                        <th> Status </th>
                                        <th> Order placed Time</th>
                                        <th> Email</th>
                                        <th> Tracking ID </th>
                                        <th> Action </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($client->p_status == 1): ?>
                                            <tr>
                                                <td> <?php echo e($loop->iteration); ?> </td>
                                                <td> <?php echo e($client->name); ?> </td>

                                                <td>
                                                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($item->p_status == 1): ?>
                                                            <?php if($item->invoiceNumber == $client->invoiceNumber): ?>
                                                                <?php echo e($loop->iteration); ?>. <?php echo e($item->name); ?><br> Quantity: <?php echo e($item->quantity); ?> , Price:<?php echo e($item->price); ?><br>
                                                                <br>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td> <?php echo e($client->totalAmount); ?> </td>
                                                <td> <?php echo e($client->address); ?> </td>
                                                <td> <?php echo e($client->phone); ?> </td>
                                                <td>
                                                    <label class="badge <?php echo e($client->delivered == 1 ? 'badge-gradient-success' : 'badge-gradient-danger'); ?>">
                                                        <?php echo e($client->delivered == 1 ? 'Delivered' : 'Not Delivered'); ?>

                                                    </label>
                                                </td>

                                                <td> <?php echo e($client->created_at); ?> </td>
                                                <td> <?php echo e($client->email); ?> </td>
                                                <td><?php echo e($client->invoiceNumber); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('delete-clint', ['invoiceNumber' => $client->invoiceNumber])); ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure Delete this Client Details ?')">Delete</a>
                                                    <form method="POST" action="<?php echo e(route('update-Delivery', ['id' => $client->id])); ?>" style="display: inline;">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="delivered" value="<?php echo e($client->delivered == 1 ? 0 : 1); ?>">
                                                        <button type="submit" class="btn btn-sm <?php echo e($client->delivered == 1 ? 'btn-danger' : 'btn-success'); ?>" style="margin-top: 5px;">
                                                            <?php echo e($client->delivered == 1 ? 'Set Not Delivered' : 'Set Delivered'); ?>

                                                        </button>
                                                    </form>
                                                </td>

                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Clients Orders With Advance Payment</h4>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th> Sl NO. </th>
                                        <th> Name </th>
                                        <th> Products </th>
                                        <th> Total Amount </th>
                                        <th> Address </th>
                                        <th> Mobile NO </th>
                                        <th> Status </th>
                                        <th> Order placed Time</th>
                                        <th> Advance Payment</th>
                                        <th> Remain Amount</th>
                                        <th> MFS</th>
                                        <th> Email</th>
                                        <th> Tracking ID </th>
                                        <th> Action </th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($client->p_status == 0): ?>
                                    <tr>
                                        <td> <?php echo e($loop->iteration); ?> </td>
                                        <td> <?php echo e($client->name); ?> </td>

                                        <td>
                                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($item->p_status == 0): ?>
                                                    <?php if($item->invoiceNumber == $client->invoiceNumber): ?>
                                                <?php echo e($loop->iteration); ?>. <?php echo e($item->name); ?><br> Quantity: <?php echo e($item->quantity); ?> , Price:<?php echo e($item->price); ?><br>
                                                <br>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td> <?php echo e($client->totalAmount); ?> </td>
                                        <td> <?php echo e($client->address); ?> </td>
                                        <td> <?php echo e($client->phone); ?> </td>
                                        <td>
                                            <label class="badge <?php echo e($client->delivered == 1 ? 'badge-gradient-success' : 'badge-gradient-danger'); ?>">
                                                <?php echo e($client->delivered == 1 ? 'Delivered' : 'Not Delivered'); ?>

                                            </label>
                                        </td>
                                        <td> <?php echo e($client->created_at); ?> </td>
                                        <td> <?php echo e($client->A_payment); ?> </td>
                                        <td> <?php echo e($client->remainAmount); ?> </td>
                                        <td> <?php echo e($client->f_service); ?> </td>
                                        <td> <?php echo e($client->email); ?> </td>
                                        <td><?php echo e($client->invoiceNumber); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('delete-clint', ['invoiceNumber' => $client->invoiceNumber])); ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure Delete this Client Details ?')">Delete</a>
                                            <form method="POST" action="<?php echo e(route('update-Delivery', ['id' => $client->id])); ?>" style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="delivered" value="<?php echo e($client->delivered == 1 ? 0 : 1); ?>">
                                                <button type="submit" class="btn btn-sm <?php echo e($client->delivered == 1 ? 'btn-danger' : 'btn-success'); ?>" style="margin-top: 5px;">
                                                    <?php echo e($client->delivered == 1 ? 'Set Not Delivered' : 'Set Delivered'); ?>

                                                </button>
                                            </form>
                                        </td>

                                    </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>


        </div>
        <!-- content-wrapper ends -->

    </div>
    <!-- main-panel ends -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmanabir/Desktop/Project/Rango/resources/views/back/pages/home.blade.php ENDPATH**/ ?>