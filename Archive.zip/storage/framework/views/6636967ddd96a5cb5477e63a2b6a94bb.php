<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('front.pages.home.navtest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <p class="slider-name text-dark font-weight-bold ">Category</p>
    <span class="divider"></span>

    <!--slider row-1 for Special Offer Products -->
    <div class="owl-carousel  image-slider" id="one">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($category->CategoryImage): ?>
            <div class="card product-item border-0 mb-4">
                <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                    <a href="<?php echo e(route('Category-All' , [ 'id' => $category->id ])); ?>"><img src="<?php echo e(asset($category->CategoryImage)); ?>" style="height: 150px; " alt="image"></a>
                </div>
                <div class="card-body border-left border-right text-center p-0 pt-4 ">
                    <a href="<?php echo e(route('Category-All' , [ 'id' => $category->id ])); ?>"> <h6 class="text-truncate mb-3"><?php echo e($category->CategoryName); ?></h6></a>

                    <div class="border">

                    </div>
                </div>
            </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <p class="slider-name text-dark font-weight-bold ">Special Offer Products</p>
    <span class="divider"></span>
    <p class="view-all"><a href="<?php echo e(route('Special-seeAll')); ?>">View All ></a></p>
    <!--slider row-1 for Special Offer Products -->
    <div class="owl-carousel  image-slider" id="two">

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($product->special_offer == 1): ?>
                <div class="card product-item border-0 mb-4">
                    <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <a href="<?php echo e(route('productDetail' , [ 'id' => $product->id ])); ?>"><img src="<?php echo e(asset($product->image)); ?>" style="height: 300px;"
                                                                                               alt="image"></a>
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 ">
                        <a href="<?php echo e(route('productDetail' , [ 'id' => $product->id ])); ?>"><h6 class="text-truncate mb-3"><?php echo e($product->productName); ?></h6></a>
                        <div class="d-flex justify-content-center">
                            <h6>৳<?php echo e(number_format($product->O_price)); ?></h6>
                            <h6 class="text-muted ml-2">
                                <del>৳<?php echo e(number_format($product->MRP_price)); ?></del>
                            </h6>
                        </div>
                        <div class="card-footer d-flex justify-content-between bg-light border">
                            <a href="<?php echo e(route('productDetail' , [ 'id' => $product->id ])); ?>" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary "></i>
                                View Detail</a>
                            <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                                <input type="hidden" value="<?php echo e($product->productName); ?>" name="name">
                                <input type="hidden" value="<?php echo e(asset($product->image)); ?>" name="image">
                                <input type="hidden" value="<?php echo e($product->O_price); ?>" name="price">
                                <input type="hidden" value="1" name="quantity">
                                <button type="submit" class="btn btn-sm text-dark p-0"><i
                                        class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>



    <p class="slider-name text-dark font-weight-bold ">All Products</p>
    <span class="divider"></span>
    <p class="view-all"><a href="<?php echo e(route('AllProduct-seeAll')); ?>">View All ></a></p>
    <!--slider row-1 for Special Offer Products -->
    <div class="owl-carousel  image-slider" id="three">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card product-item border-0 mb-4">
                <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                    <a href="<?php echo e(route('productDetail' , [ 'id' => $product->id ])); ?>"><img src="<?php echo e(asset($product->image)); ?>" style="height: 300px; " alt="image"></a>
                </div>
                <div class="card-body border-left border-right text-center p-0 pt-4 ">
                    <a href="<?php echo e(route('productDetail' , [ 'id' => $product->id ])); ?>"> <h6 class="text-truncate mb-3"><?php echo e($product->productName); ?></h6></a>
                    <div class="d-flex justify-content-center">
                        <h6>৳<?php echo e(number_format($product->O_price)); ?></h6>
                        <h6 class="text-muted ml-2">
                            <del>৳<?php echo e(number_format($product->MRP_price)); ?></del>
                        </h6>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="<?php echo e(route('productDetail' , [ 'id' => $product->id ])); ?>" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary "></i>View Detail</a>
                        <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                            <input type="hidden" value="<?php echo e($product->productName); ?>" name="name">
                            <input type="hidden" value="<?php echo e(asset($product->image)); ?>" name="image">
                            <input type="hidden" value="<?php echo e($product->O_price); ?>" name="price">
                            <input type="hidden" value="1" name="quantity">
                            <button type="submit" class="btn btn-sm text-dark p-0"><i
                                    class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>



    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <!--slider row-2-->
        <p class="slider-name text-dark font-weight-bold"><?php echo e($category->CategoryName); ?></p>
        <span class="divider"></span>
        <p class="view-all"><a href="<?php echo e(route('Category-seeAll', ['id' => $category->id])); ?>">View All></a></p>
        <div class="owl-carousel  image-slider" id="four">

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($category->id == $product->category_id): ?>
                    <div class="card product-item border-0 mb-4">
                        <div
                            class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                            <a href="<?php echo e(route('productDetail' , [ 'id' => $product->id ])); ?>"><img src="<?php echo e(asset($product->image)); ?> " style="height: 300px;" alt="image"></a>
                        </div>
                        <div class="card-body border-left border-right text-center p-0 pt-4 ">
                            <a href="<?php echo e(route('productDetail' , [ 'id' => $product->id ])); ?>"> <h6 class="text-truncate mb-3"><?php echo e($product->productName); ?></h6></a>
                            <div class="d-flex justify-content-center">
                                <h6>৳<?php echo e(number_format($product->O_price)); ?></h6>
                                <h6 class="text-muted ml-2">
                                    <del>৳<?php echo e(number_format($product->MRP_price)); ?></del>
                                </h6>
                            </div>
                            <div class="card-footer d-flex justify-content-between bg-light border">
                                <a href="<?php echo e(route('productDetail' , [ 'id' => $product->id ])); ?>" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary "></i>View Detail</a>
                                <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                                    <input type="hidden" value="<?php echo e($product->productName); ?>" name="name">
                                    <input type="hidden" value="<?php echo e(asset($product->image)); ?>" name="image">
                                    <input type="hidden" value="<?php echo e($product->O_price); ?>" name="price">
                                    <input type="hidden" value="1" name="quantity">
                                    <button type="submit" class="btn btn-sm text-dark p-0"><i
                                            class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    <h1 class="text-center bg-danger">Brands</h1>
    <!--last row-->
    <div class="owl-carousel image-slider " id="five">

        <?php
            $sameBrandIds = [];
            $brandImages = [];

            foreach ($brands as $brand) {
                if (!in_array($brand->BrandName, array_keys($sameBrandIds))) {
                    $sameBrandIds[$brand->BrandName] = [$brand->id];
                    $brandImages[$brand->BrandName] = $brand->BrandImage;
                } else {
                    $sameBrandIds[$brand->BrandName][] = $brand->id;
                }
            }
        ?>

        <?php $__currentLoopData = $sameBrandIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brandName => $ids): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($brandImages[$brandName]): ?>
            <div class="card product-item border-0 mb-4">
                <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                    <p><?php echo e($brandName); ?></p>
                    <a href="<?php echo e(route('brand.all.products', ['ids' => implode(',', $ids)])); ?>">
                        <img src="<?php echo e(asset($brandImages[$brandName])); ?>" style="height: 150px;" width="150px;"
                             alt="Brand image">
                    </a>
                </div>
            </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <!--script for last row-->

    <iframe src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d3651.2766210342043!2d90.426187!3d23.773162!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMjPCsDQ2JzIzLjQiTiA5MMKwMjUnMzQuMyJF!5e0!3m2!1sen!2sbd!4v1693077221396!5m2!1sen!2sbd" width="100%" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">

    </iframe>




















<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmanabir/Desktop/Project/Rango/resources/views/front/pages/home/home.blade.php ENDPATH**/ ?>