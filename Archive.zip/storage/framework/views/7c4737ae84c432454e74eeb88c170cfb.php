<link href="<?php echo e(asset('/')); ?>assets/front-asset/css/navCategories.css" rel="stylesheet">
<div class="container-fluid  mb-1 mt-1" style="background-color: #800000; height: 68px">
    <div class="row border-top px-xl-6">
        <div class="col-lg-2">
            <!-- Category Bar -->

            <!-- Category Bar for Desktop View -->
            <a class="btn d-flex align-items-center justify-content-between text-white w-100 " data-toggle="collapse" data-target="#category-bar"  href="#navbar-vertical" style="height: 65px; margin-top: -1px; padding: 0 30px;">
                <h6 class="m-0" style="color: gold">Categories</h6>
                <i class="fa fa-angle-down text-warning "></i>
            </a>
            <!-- ... (Other category links for desktop view) ... -->
        </div>
        <!-- Rest of the content (Navigation bar, Carousel, etc.) -->
        <div class="col-lg-10">
            <!-- Navigation Bar -->
            <nav class="navbar navbar-expand-lg py-3 py-lg-0 px-0">
                <!-- ... (Existing Navigation Links) ... -->
                <a href="" class="text-decoration-none d-block d-lg-none">
                    <h1 class="m-0 display-5 font-weight-semi-bold">
                        <span class="text-primary font-weight-bold border px-3 mr-1">Rango</span>Electronics
                    </h1>
                </a>
                <button type="button" class="navbar-toggler" style="position: relative;  " data-toggle="collapse" data-target="#navbarCollapse">
                    <span class="navbar-toggler-icon fa-solid fa-bars"><i ></i></span>
                </button>
                <div class="collapse navbar-collapse justify-content-center navbar-nav-visible" style="height: 67px; margin-right: 300px;" id="navbarCollapse">
                    <div class="navbar-nav " style="color: black;">
                        <a href="<?php echo e(route('home')); ?>" class="nav-item nav-link active" style="color: gold; font-weight: bold; margin-left: 50px;">Home</a>
                        <a href="<?php echo e(route('All-Brands')); ?>" class="nav-item nav-link" style="color: gold; font-weight: bold; margin-left: 50px;">Brands</a>
                        <a href="<?php echo e(route('menu.installation')); ?>" class="nav-item nav-link" style="color: gold; font-weight: bold; margin-left: 50px;">Installation & Services</a>
                        <a href="<?php echo e(route('menu.contact')); ?>" class="nav-item nav-link" style="color: gold; font-weight: bold; margin-left: 50px;">Contact</a>
                    </div>
                </div>
            </nav>
        </div>
    </div>
</div>
<div class=" col-lg-12 row">
    <div class="col-lg-3">
        <nav class="  navbar-collapse show navbar navbar-vertical align-items-start p-0 border border-top-0 border-bottom-0"    >
            <div class="navbar-nav w-100 overflow-auto" >
                <div class="category-bar  collapse show category-bar-visible" >
                    <div class="category-list">
                        <nav class="navCategory" >
                            <ul class="">
                                
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="dropdown"><a href="<?php echo e(route('Category-All', ['id' => $category->id])); ?>"><?php echo e($category->CategoryName); ?><span>&rsaquo;</span></a>
                                        <ul>
                                            
                                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($category->id == $brand->category_id): ?>
                                                    <li class="dropdown_two"><a href="<?php echo e(route('category.wise.brand' , ['id' => $brand->id ])); ?>"><?php echo e($brand->BrandName); ?><span>&rsaquo;</span></a>
                                                        <ul>
                                                            
                                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($product->category_id == $category->id && $product->brand_id == $brand->id): ?>
                                                                    <li><a href="<?php echo e(route('type.of.product' ,[ 'id' => $product->id] )); ?>"><?php echo e($product->product_type); ?></a></li>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                        <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </li>
                                        </ul>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </nav>
    </div>

    <div class="col-lg-6">
        <!-- Carousel and Content Here -->
        <!-- ... (Carousel content here) ... -->
        <div id="header-carousel" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner" style="border-radius: 20px;">
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index =>$slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>" style="height: auto;">
                        <img class="img-fluid" src="<?php echo e(asset($slider->slidImage)); ?>" style="border-radius: 20px;"  alt="Image">
                        <div class="carousel-caption d-flex flex-column align-items-center justify-content-center" style="padding: 15px;">
                            <div class="p-3" style="max-width: 700px; border-radius: 50px;">
                                <h4 class="text-light text-uppercase font-weight-medium mb-3"><?php echo e($slider->sliderStext); ?></h4>
                                <h3 class="display-4 text-white font-weight-semi-bold mb-4"><?php echo e($slider->sliderBtext); ?></h3>
                                
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <a class="carousel-control-prev" href="#header-carousel" data-slide="prev">
                <div class="btn btn-dark" style="width: 45px; height: 45px;">
                    <span class="carousel-control-prev-icon mb-n2"></span>
                </div>
            </a>
            <a class="carousel-control-next" href="#header-carousel" data-slide="next">
                <div class="btn btn-dark" style="width: 45px; height: 45px;">
                    <span class="carousel-control-next-icon mb-n2"></span>
                </div>
            </a>
        </div>
    </div>


    <div class="col-lg-3">
        <img src="<?php echo e(asset('/')); ?>assets/front-asset/img/ad1.jpg" alt="" class="img-fluid d-none d-lg-block" style="height: 200px; width: 420px; border-radius: 20px; margin-bottom: 10px;">
        <img src="<?php echo e(asset('/')); ?>assets/front-asset/img/ad2.jpg" alt="" class="img-fluid d-none d-lg-block" style="height: 200px; width: 420px; border-radius: 20px;">
    </div>
</div>
<!-- ... (Your HTML and CSS) ... -->
<div class="row d-block d-lg-none">
    <div class="col-12 mt-1">
        <!-- Advertisements for mobile -->
        <img src="<?php echo e(asset('/')); ?>assets/front-asset/img/ad1.jpg" alt="" class="img-fluid" style="height: auto; max-width: 100%; border-radius: 20px; margin-bottom: 10px;">
        <img src="<?php echo e(asset('/')); ?>assets/front-asset/img/ad2.jpg" alt="" class="img-fluid" style="height: auto; max-width: 100%; border-radius: 20px;">

        <!-- ... (Mobile advertisements code) ... -->
    </div>
</div>


<script>
    document.addEventListener("DOMContentLoaded", function () {
        const categoryBar = document.querySelector(".category-bar");
        const categoryButton = document.querySelector("[data-target='#category-bar']");

        categoryButton.addEventListener("click", function () {
            categoryBar.classList.toggle("show"); // Toggle the show class

            // Adjust the max-height of the category bar based on its visibility
            if (categoryBar.classList.contains("show")) {
                categoryBar.style.maxHeight = categoryBar.scrollHeight + "px";
            } else {
                categoryBar.style.maxHeight = "0";
            }
        });
    });
</script>



<script>
    document.addEventListener("DOMContentLoaded", function () {
        const navbarNav = document.querySelector(".navbar-nav");
        const navButton = document.querySelector("[data-target='#navbarCollapse']");

        navbarNav.addEventListener("click", function () {
            navbarNav.classList.toggle("show"); // Toggle the show class
            // Adjust the max-height of the category bar based on its visibility
            if (navbarNav.classList.contains("show")) {
                navbarNav.style.maxHeight = navbarNav.scrollHeight + "px";
            } else {
                navbarNav.style.maxHeight = "0";
            }
        });
    });
</script>







<?php /**PATH /Users/rahmanabir/Desktop/Project/Rango/resources/views/front/pages/home/navCategories.blade.php ENDPATH**/ ?>