
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo e(asset('/')); ?>assets/front-asset/css/tobarTwo.css" rel="stylesheet">


<nav class="sticky-nav">
    <div class="container-fluid" style="background-color: #800000;">
        <div class="row align-items-center">
            <div class="col-md-3">
                <!-- Logo and Branding -->
                <div class="d-flex justify-content-start align-items-center">
                    <a href="<?php echo e(route('home.w.l')); ?>" class="text-decoration-none ml-3">
                        <img style="max-width: 100%;" src="<?php echo e(asset('/')); ?>assets/front-asset/img/rongologo.png" alt="Rongo Logo">
                    </a>
                    <a href="<?php echo e(route('home.w.l')); ?>" class="text-decoration-none">
                        <img style="max-width: 100%;" src="<?php echo e(asset('/')); ?>assets/front-asset/img/rongotext.png" alt="Rongo Text">
                    </a>
                </div>
            </div>
            <div class="col-md-6">
                <!-- Search Form -->
                <form class="form-inline" action="<?php echo e(route('search.result')); ?>" method="GET">
                    <?php echo csrf_field(); ?>
                    <div class="input-group w-100">
                        <input type="text" name="query" class="form-control" placeholder="Search for products">
                        <div class="input-group-append">
                            <button class="btn bg-danger" type="submit">
                                <i class="fa fa-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-md-3">
                <!-- Navigation Icons and Toggle Button -->
                <div class="d-flex justify-content-center align-items-center">
                    <?php if(optional(Auth::user())->role == 565001): ?>
                        <a href="<?php echo e(route('dashboard')); ?>" class="text-decoration-none pr-3">
                            <i class="fa-solid fa-user" style="color: gold;">Admin</i> <label for=""><?php echo e(explode(' ', Auth::user()->name)[0]); ?></label>
                        </a>

                        <a href="#" class="text-decoration-none pr-3" onclick="event.preventDefault();document.getElementById('logoutabir').submit();">
                            <i class="fa-solid fa-right-from-bracket" style="color: #f3bd29;"></i>
                        </a>
                        <form action="<?php echo e(route('logout')); ?>" method="POST" id="logoutabir"><?php echo csrf_field(); ?></form>

                    <?php elseif(Auth::check()): ?>
                        <a href="<?php echo e(route('dashboard')); ?>" class="text-decoration-none pr-3">
                            <i class="fa-solid fa-user" style="color: gold;"></i><?php echo e(implode(' ', array_slice(explode(' ', Auth::user()->name), 0, 2))); ?>

                        </a>

                        <a href="#" class="text-decoration-none pr-3" onclick="event.preventDefault();document.getElementById('logoutabir').submit();">
                            <i class="fa-solid fa-right-from-bracket" style="color: #f3bd29;"></i>
                        </a>
                        <form action="<?php echo e(route('logout')); ?>" method="POST" id="logoutabir"><?php echo csrf_field(); ?></form>

                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="text-decoration-none pr-3">
                            <i class="fa-solid fa-user"style="color: gold;"></i>
                        </a>
                    <?php endif; ?>
                        
                        <a href="<?php echo e(route('cart.list')); ?>" class="text-decoration-none pr-3">
                            <i class="fa-solid fa-cart-flatbed-suitcase" style="color: gold;"></i> <?php echo e(Cart::getTotalQuantity()); ?>

                        </a>

                        
                </div>
            </div>
        </div>
    </div>
</nav>



<?php /**PATH /Users/rahmanabir/Desktop/Rango All Work/Rango/resources/views/front/includes/tobarTwo.blade.php ENDPATH**/ ?>