<?php $__env->startSection('title'); ?>
    All Brands
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('front.includes.navCategoryForOthers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid pt-2">
        <div class="text-center mb-1">
            <h2 class="section-title px-5"><span class="px-2">All Brands are Here</span></h2>
        </div>
        <div class="row px-xl-5 pb-3">
            <?php
                $sameBrandIds = [];
                $brandImages = [];

                foreach ($brands as $brand) {
                   if (!in_array($brand->BrandName, array_keys($sameBrandIds))) {
                       $sameBrandIds[$brand->BrandName] = [$brand->id];
                       $brandImages[$brand->BrandName] = $brand->BrandImage;
                   } else {
                       $sameBrandIds[$brand->BrandName][] = $brand->id;
                   }
                }
            ?>


            <?php $__currentLoopData = $sameBrandIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brandName => $ids): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($brandImages[$brandName]): ?>
                <div class="col-lg-2 col-md-2 col-sm-3">
                    <div class=" product-item border-0 mb-4">
                        <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                            <a href="<?php echo e(route('brand.all.products', ['ids' => implode(',', $ids)])); ?>" >
                                <img src="<?php echo e(asset($brandImages[$brandName])); ?>" class="img-fluid" alt="Brand image">
                            </a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
<?php $__env->stopSection(); ?>


















<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmanabir/Desktop/Project/Rango/resources/views/front/pages/menu/brands.blade.php ENDPATH**/ ?>