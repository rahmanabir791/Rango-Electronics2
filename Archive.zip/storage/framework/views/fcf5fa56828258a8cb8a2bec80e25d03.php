<?php echo $__env->make('home.includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

<!-- Topbar Start -->
<?php echo $__env->make('home.includes.topbarOne', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('home.includes.tobarTwo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Topbar End -->


<!-- Navbar Start -->

<?php echo $__env->make('home.includes.navCategories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('home.includes.navTwo,searchbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <?php echo $__env->make('home.includes.carousel_slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Navbar End -->


<?php echo $__env->yieldContent('body'); ?>

<!-- Footer Start -->
<?php echo $__env->make('home.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer End -->

<?php echo $__env->make('home.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\My work\Rango\resources\views/home/master.blade.php ENDPATH**/ ?>