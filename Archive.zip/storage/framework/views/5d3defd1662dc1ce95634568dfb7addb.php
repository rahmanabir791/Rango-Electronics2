<?php $__env->startSection('title'); ?>
    ADD Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="main-panel">

            <div class="content-wrapper">

                <div class="col-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Add Category</h4>
                            <p class="card-description">Enter the category name and submit</p>
                            <form method="post" action="<?php echo e(route('new-category')); ?>" class="form-inline" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <label class="sr-only" for="categoryName">Category Name</label>
                                <input type="text" name="category_name" class="form-control mb-2 mr-sm-2" id="categoryName" placeholder="Category Name" required>

                                <button type="submit" class="btn btn-gradient-primary mb-2">Add Category</button>
                            </form>
                        </div>
                    </div>
                </div>


            </div>
            </div>


        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmanabir/Desktop/Rango All Work/Rango/resources/views/back/pages/category/Add_category.blade.php ENDPATH**/ ?>