
<div class="row" style="background-color: gold; height: 35px">
    <div class="col-lg-12 ">


<div class="row" style="background-color: maroon; color: white;">
    <div class="col-lg-6 d-none d-lg-block">
        <div class="d-inline-flex align-items-center">
            <a class="text-white px-2" href="">
                <i class="fa-solid fa-phone-volume"></i>
            </a>
            <span class="text-white px-1">+8801800000000</span>
            <span class="text-muted px-2">|</span>
            <a class="text-white px-2" href="">
                <i class="fa-solid fa-envelope"></i>
            </a>
            <span class="text-white px-2">rangoelectronics.com</span>
        </div>
    </div>
    <div class="col-lg-6 text-center text-lg-right">
        <div class="d-inline-flex align-items-center">
            <a class="text-white px-1" href="">
                <i class="fab fa-facebook-f"></i>
            </a>
            <a class="text-white px-1" href="">
                <i class="fab fa-twitter"></i>
            </a>
            <a class="text-white px-1" href="">
                <i class="fab fa-linkedin-in"></i>
            </a>
            <a class="text-white px-1" href="">
                <i class="fab fa-instagram"></i>
            </a>
            <a class="text-white px-1" href="">
                <i class="fab fa-youtube"></i>
            </a>
        </div>
    </div>
</div>



    </div>
</div>

<?php /**PATH /Users/rahmanabir/Desktop/Rango/resources/views/front/includes/topbarOne.blade.php ENDPATH**/ ?>