<div class="container-fluid">
    <div class="row py-2 px-xl-5" style="background-color: maroon; color:white;">
        <div class="col-lg-6 d-none d-lg-block">
            <div class="d-inline-flex align-items-center">
                <a class="text-white px-2" href="">
                    <i class="fa-solid fa-phone-volume"></i>
                </a>
                <span class="text-white px-2">+88018634753</span>
                <span class="text-muted px-2">|</span>
                <a class="text-white px-2" href="">
                    <a class="text-white px-2" href="">
                        <i class="fa-solid fa-envelope"></i>
                    </a>
                </a>
                <span class="text-white px-2">rangoelectronics.com</span>
            </div>
        </div>
        <div class="col-lg-6 text-center text-lg-right">
            <div class="d-inline-flex align-items-center">
                <a class="text-white px-2" href="">
                    <i class="fab fa-facebook-f"></i>
                </a>
                <a class="text-white px-2" href="">
                    <i class="fab fa-twitter"></i>
                </a>
                <a class="text-white px-2" href="">
                    <i class="fab fa-linkedin-in"></i>
                </a>
                <a class="text-white px-2" href="">
                    <i class="fab fa-instagram"></i>
                </a>
                <a class="text-white pl-2" href="">
                    <i class="fab fa-youtube"></i>
                </a>
            </div>
        </div>
    </div>
<?php /**PATH D:\My work\Rango\resources\views/home/includes/topbarOne.blade.php ENDPATH**/ ?>