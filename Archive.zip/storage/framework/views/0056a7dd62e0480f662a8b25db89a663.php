<?php $__env->startSection('title'); ?>
    See all
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('front.includes.navCategoryForOthers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid pt-5">
        <div class="text-center mb-4">
            <h2 class="section-title px-5"><span class="px-2">All Special Offer Products Here</span></h2>
        </div>
        <div class="row px-xl-5 pb-3">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($product->special_offer == 1): ?>
                    <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                        <div class="card product-item border-0 mb-4">
                            <div
                                class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                                <img class="img-fluid w-100" src="<?php echo e(asset($product->image)); ?>"
                                     style="height: 300px; width: 150px;" alt="">
                            </div>
                            <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                                <h6 class="text-truncate mb-3"><?php echo e($product->productName); ?></h6>
                                <div class="d-flex justify-content-center">
                                    <h6>৳<?php echo e(number_format($product->MRP_price)); ?></h6>
                                    <h6 class="text-muted ml-2">
                                        <del>৳<?php echo e(number_format($product->O_price)); ?></del>
                                    </h6>
                                </div>
                            </div>
                            <div class="card-footer d-flex justify-content-between bg-light border">
                                <a href="<?php echo e(route('productDetail' , [ 'id' => $product->id ])); ?>" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary "></i></a>
                                <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                                    <input type="hidden" value="<?php echo e($product->productName); ?>" name="name">
                                    <input type="hidden" value="<?php echo e(asset($product->image)); ?>" name="image">
                                    <input type="hidden" value="<?php echo e($product->O_price); ?>" name="price">
                                    <input type="hidden" value="1" name="quantity">
                                    <button type="submit" class="btn btn-sm text-dark p-0"><i
                                            class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmanabir/Desktop/Rango All Work/Rango/resources/views/front/pages/view_all_pages/special_offer.blade.php ENDPATH**/ ?>