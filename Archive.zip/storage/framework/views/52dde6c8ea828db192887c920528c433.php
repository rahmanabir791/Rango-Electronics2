<?php $__env->startSection('body'); ?>



    <div class="main-panel">
        <div class="content-wrapper">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover border-5">
                            <thead>
                            <tr class="border-5">
                                <th class="border-5">#</th>
                                <th class="border-5">Product Name</th>
                                <th class="border-5">Category Name</th>
                                <th class="border-5">Brand Name</th>
                                <th class="border-5">Type</th>
                                <th class="border-5">MRP Price</th>
                                <th class="border-5">Offer Price</th>
                                <th class="border-5">Special Offer</th>
                                <th class="border-5">Stock</th>
                                <th class="border-5">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <!-- Loop through products for each brand -->
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $Products = $products->where('brand_id', $Brand->id);
                                ?>

                                <?php if($Products->isNotEmpty()): ?>
                                    <tr>
                                        <td colspan="10"><h4>Brand Name: <?php echo e($Brand->BrandName); ?></h4></td>
                                    </tr>
                                    <!-- Loop through products within a brand -->
                                    <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="border-5"><?php echo e($loop->iteration); ?></td>
                                            <td class="border-5"><?php echo e($product->productName); ?></td>
                                            <td><?php echo e($product->category->CategoryName); ?></td>
                                            <td><?php echo e($product->brand->BrandName); ?></td>
                                            <td class="border-5"><?php echo e($product->product_type); ?></td>
                                            <td class="border-5"><?php echo e($product->MRP_price); ?></td>
                                            <td class="border-5"><?php echo e($product->O_price); ?></td>
                                            <!-- ... Special offer and stock columns ... -->
                                            <td class="border-5" style="text-align: center; padding: 10px;">
                                                <!-- Special offer form and button... -->
                                                <span style="font-weight: bold; color: <?php echo e($product->stockAvailability == 1 ? 'green' : 'red'); ?>;">
                                                    <?php echo e($product->special_offer == 1 ? 'In Special Offer' : 'Out Of Special Offer'); ?>

                                                </span>
                                                <form method="POST" action="<?php echo e(route('update-special_Offer', ['id' => $product->id])); ?>" style="display: inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="special_offer" value="<?php echo e($product->special_offer == 1 ? 0 : 1); ?>">
                                                    <button type="submit" class="btn btn-sm <?php echo e($product->special_offer == 1 ? 'btn-danger' : 'btn-success'); ?>" style="margin-top: 5px;">
                                                        <?php echo e($product->special_offer == 1 ? 'Set Out of Special Offer' : 'Set In Special Offer'); ?>

                                                    </button>
                                                </form>
                                            </td>
                                            <!-- ... Similar code for stock ... -->
                                            <td class="border-5">
                                                <!-- Edit and delete buttons... -->
                                                <a href="<?php echo e(route('edit-product', ['id' => $product->id])); ?>" class="btn btn-sm btn-secondary btn-outline-info">Edit</a>
                                                <br>
                                                <a href="<?php echo e(route('delete-product', ['id' => $product->id])); ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this product?')">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <!-- Loop through products without a brand -->
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(empty($product->brand_id)): ?>
                                    <tr>
                                        <td colspan="10"><h2>This product has no brand!!!</h2></td>
                                    </tr>
                                    <tr>
                                        <td class="border-5"><?php echo e($loop->iteration); ?></td>
                                        <td class="border-5"><?php echo e($product->productName); ?></td>
                                        <td><?php echo e($product->category_id); ?> - <?php echo e($product->category_name); ?></td>
                                        <td><?php echo e($product->brand_id); ?> - <?php echo e($product->brand_name); ?></td>
                                        <td class="border-5"><?php echo e($product->product_type); ?></td>
                                        <td class="border-5"><?php echo e($product->MRP_price); ?></td>
                                        <td class="border-5"><?php echo e($product->O_price); ?></td>
                                        <!-- ... Special offer and stock columns ... -->
                                        <td class="border-5" style="text-align: center; padding: 10px;">
                                            <!-- Special offer form and button... -->
                                            <span style="font-weight: bold; color: <?php echo e($product->stockAvailability == 1 ? 'green' : 'red'); ?>;">
                                                <?php echo e($product->special_offer == 1 ? 'In Special Offer' : 'Out Of Special Offer'); ?>

                                            </span>
                                            <form method="POST" action="<?php echo e(route('update-special_Offer', ['id' => $product->id])); ?>" style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="special_offer" value="<?php echo e($product->special_offer == 1 ? 0 : 1); ?>">
                                                <button type="submit" class="btn btn-sm <?php echo e($product->special_offer == 1 ? 'btn-danger' : 'btn-success'); ?>" style="margin-top: 5px;">
                                                    <?php echo e($product->special_offer == 1 ? 'Set Out of Special Offer' : 'Set In Special Offer'); ?>

                                                </button>
                                            </form>
                                        </td>
                                        <!-- ... Similar code for stock ... -->
                                        <td class="border-5">
                                            <!-- Edit and delete buttons... -->
                                            <a href="<?php echo e(route('edit-product', ['id' => $product->id])); ?>" class="btn btn-sm btn-secondary btn-outline-info">Edit</a>
                                            <br>
                                            <a href="<?php echo e(route('delete-product', ['id' => $product->id])); ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this product?')">Delete</a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>








<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmanabir/Desktop/Rango All Work/Rango/resources/views/search_results.blade.php ENDPATH**/ ?>