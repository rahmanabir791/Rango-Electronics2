<?php $__env->startSection('title'); ?>
    Add Slider
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Add Slider Data</h4>
                        <form action="<?php echo e(route('newSlider')); ?>" method="post" class="form-inline" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <input type="text" name="sliderStext" class="form-control mb-2 mr-sm-2"  placeholder="Upper Line / Small Line / offer text">

                            <div class="input-group mb-2 mr-sm-2">

                                <input type="text" name="sliderBtext" class="form-control" id="inlineFormInputGroupUsername2" placeholder="Below Line | Name ">
                            </div>
                            <div class="input-group mb-2 mr-sm-2">

                                <input type="file" accept="image/*" name="slidImage" class="form-control" id="inlineFormInputGroupUsername2" placeholder="Slider Image" required>
                            </div>
                            <button type="submit" class="btn btn-gradient-primary mb-2">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- content-wrapper ends -->
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('back.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmanabir/Desktop/Rango All Work/Rango/resources/views/back/pages/slider/Add_slider.blade.php ENDPATH**/ ?>