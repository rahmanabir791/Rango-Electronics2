<style>
    /* Style for the subcategories */
    .nav-item {
        position: relative;
        display: inline-block;
    }

    .nav-item .dropdown-menu {
        display: none;
        position: absolute;
    }

    .nav-item:hover .dropdown-menu {
        display: block;
    }
</style>

<div class="container-fluid mb-5">
    <div class="row border-top">
        <div class="col-lg-3 d-lg-block">
            <a class="btn shadow-none d-flex align-items-center justify-content-between text-white w-100" data-toggle="collapse" href="#navbar-vertical" style="height: 65px; margin-top: -1px; padding: 0 30px; background-color: maroon;">
                <h6 class="m-0" style="color: white;">Categories</h6>
                <i class="fa fa-angle-down text-dark"></i>
            </a>
            <!-- Rest of your category navigation code -->
            <nav class="navbar navbar-vertical navbar-light align-items-start p-0 border border-top-0 border-bottom-0" id="navbar-vertical">
                <div class="navbar-nav w-100 overflow-hidden" style="max-height: 410px;">
                    <!-- Category dropdown and links -->
                    <div class="nav-item dropdown show">
                        <a href="#" class="nav-link" data-toggle="dropdown">Electrics<i class="fa fa-angle-right float-right mt-1"></i></a>
                        <div class="dropdown-menu  position-absolute bg-secondary border-0 rounded-0 w-100 m-0">
                            <a href="#" class="dropdown-item">Fan</a>
                            <a href="#" class="dropdown-item">Light</a>
                            <a href="#" class="dropdown-item">Plugs</a>
                        </div>
                    </div>

                    <!-- Other category links -->
                    <a href="#" class="nav-item nav-link">Refrigerator</a>
                    <a href="#" class="nav-item nav-link">Television</a>
                    <a href="#" class="nav-item nav-link">Air Conditioner</a>
                    <a href="#" class="nav-item nav-link">Washing Machine</a>
                    <a href="#" class="nav-item nav-link">Water Purifier</a>
                    <a href="#" class="nav-item nav-link">Electronic Item</a>
                </div>
            </nav>



        </div>

        <div class="col-lg-9">
            <div class="col-12">
                <!-- Place your slider here -->
                <div id="header-carousel" class="carousel slide" data-ride="carousel">
                    <!-- Rest of your carousel code remains the same -->
                    <div class="carousel-inner">
                        <div class="carousel-item active" style="height: 410px;">
                            <img class="img-fluid" src="<?php echo e(asset('/')); ?>assets/front-asset/img/slider.jpeg" alt="Image">
                            <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                                <div class="p-3" style="max-width: 700px;">
                                    <h4 class="text-light text-uppercase font-weight-medium mb-3">10% Off Your First Order</h4>
                                    <h3 class="display-4 text-white font-weight-semi-bold mb-4">Electronics Products</h3>

                                </div>
                            </div>
                        </div>
                        <div class="carousel-item" style="height: 410px;">
                            <img class="img-fluid" src="<?php echo e(asset('/')); ?>assets/front-asset/img/slider.jpeg" alt="Image">
                            <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                                <div class="p-3" style="max-width: 700px;">
                                    <h4 class="text-light text-uppercase font-weight-medium mb-3">10% Off Your First Order</h4>
                                    <h3 class="display-4 text-white font-weight-semi-bold mb-4">Reasonable Price</h3>

                                </div>
                            </div>
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#header-carousel" data-slide="prev">
                        <div class="btn btn-dark" style="width: 45px; height: 45px;">
                            <span class="carousel-control-prev-icon mb-n2"></span>
                        </div>
                    </a>
                    <a class="carousel-control-next" href="#header-carousel" data-slide="next">
                        <div class="btn btn-dark" style="width: 45px; height: 45px;">
                            <span class="carousel-control-next-icon mb-n2"></span>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Users/rahmanabir/Desktop/Rango/resources/views/home/pages/navCategories.blade.php ENDPATH**/ ?>