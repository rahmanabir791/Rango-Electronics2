<?php $__env->startSection('title'); ?>
    Contact Message
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <div class="main-panel">
        <div class="content-wrapper">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover border-5">
                            <thead>
                            <tr class="border-5">
                                <th class="border-5">#</th>
                                <th class="border-5">Name</th>
                                <th class="border-5">Email</th>
                                <th class="border-5">Subject</th>
                                <th class="border-5">Message</th>
                                <th class="border-5">Action</th>

                            </tr>
                            </thead>
                            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                            <tr>
                                <td class="border-5"><?php echo e($loop->iteration); ?></td>
                                <td class="border-5"><?php echo e($message->name); ?></td>
                                <td class="border-5"><?php echo e($message->email); ?></td>
                                <td class="border-5"><?php echo e($message->subject); ?></td>
                                <td class="border-5"><?php echo e($message->message); ?></td>

                                <td class="border-5">
                                    
                                    <br>
                                    <a href="<?php echo e(route('delete-message', ['id' => $message->id])); ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure Delete this Brand?')">Delete</a>
                                </td>
                            </tr>
                            </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>




<?php echo $__env->make('back.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmanabir/Desktop/Rango All Work/Rango/resources/views/back/pages/contacts/contacts.blade.php ENDPATH**/ ?>