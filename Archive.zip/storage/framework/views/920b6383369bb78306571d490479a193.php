<?php $__env->startSection('title'); ?>
    Type of Products
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('front.includes.navCategoryForOthers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid pt-5">
        <div class="text-center mb-4">
            <?php if(count($products) > 0): ?>
                <?php
                    $product = $products->first();
                    $matchingBrand = $brands->where('id', $product->brand_id)->first();
                    $matchingCategory = $categories->where('id', $product->category_id)->first();
                ?>

                <?php if($matchingBrand && $matchingCategory): ?>
                    <h2 class="section-title px-5">
                    <span class="px-2">
                        All <?php echo e($matchingBrand->BrandName); ?> Brand -> <?php echo e($product->product_type); ?> -> <?php echo e($matchingCategory->CategoryName); ?> Here
                    </span>
                    </h2>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="row px-xl-5 pb-3">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="card product-item border-0 mb-4" >
                    <div
                        class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                        <a href="<?php echo e(route('productDetail' , [ 'id' => $product->id ])); ?>"><img class="img-fluid w-100" src="<?php echo e(asset($product->image)); ?>" style="height: 200px;" alt="Brand Image"></a>
                    </div>
                    <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                        <a href="<?php echo e(route('productDetail' , [ 'id' => $product->id ])); ?>"><h6 class="text-truncate mb-3"><?php echo e($product->productName); ?></h6></a>
                        <div class="d-flex justify-content-center">
                            <h6>৳<?php echo e(number_format($product->O_price)); ?></h6>
                            <h6 class="text-muted ml-2">
                                <del>৳<?php echo e(number_format($product->MRP_price)); ?></del>
                            </h6>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between bg-light border">
                        <a href="<?php echo e(route('productDetail' , [ 'id' => $product->id ])); ?>" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary "></i>View Detail</a>
                        <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                            <input type="hidden" value="<?php echo e($product->productName); ?>" name="name">
                            <input type="hidden" value="<?php echo e(asset($product->image)); ?>" name="image">
                            <input type="hidden" value="<?php echo e($product->O_price); ?>" name="price">
                            <input type="hidden" value="1" name="quantity">
                            <button type="submit" class="btn btn-sm text-dark p-0"><i
                                    class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmanabir/Desktop/Project/Rango/resources/views/front/pages/categoryBarView/typeOfProducts.blade.php ENDPATH**/ ?>