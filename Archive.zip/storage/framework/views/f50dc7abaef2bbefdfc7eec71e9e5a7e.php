<!DOCTYPE html>
<html lang="en">
<head>
<?php echo $__env->make('back.include.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
<div class="container-scroller">

    <?php echo $__env->make('back.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
     <?php echo $__env->make('back.include.sidebarmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('body'); ?>

    </div>
    <!-- page-body-wrapper ends -->
</div>
    <?php echo $__env->make('back.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('back.include.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /Users/rahmanabir/Desktop/Rango All Work/Rango/resources/views/back/master.blade.php ENDPATH**/ ?>