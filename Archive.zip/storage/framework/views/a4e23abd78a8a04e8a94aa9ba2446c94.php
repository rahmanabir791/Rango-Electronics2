<style>
    .dividerTop{
        height: 1px;
        width: auto;
        margin-left: 4px;
        background: gold;

    }
</style>

<div class="col-lg-12" style="background-color: gold; height: auto;">
    <!-- Small Golden Bar -->
    <div class="row" style="background-color: maroon; color: white;">
        <div class="col-lg-6 d-none d-lg-block">
            <div class="d-inline-flex align-items-center">
                <a class="text-white px-2" href="tel:+8801798565001">
                    <i class="fa-solid fa-phone-volume"></i>
                    <span class="text-white px-1">+8801798-565001</span>
                </a>
                <span class="text-muted px-2">|</span>
                <a class="text-white px-2" href="mailto:electronics.rango@gmail.com">
                    <i class="fa-solid fa-envelope"></i>
                    <span class="text-white px-2">electronics.rango@gmail.com</span>
                </a>
            </div>
        </div>
        <div class="col-lg-6 text-center text-lg-right">
            <div class="d-none d-sm-inline-flex align-items-center">
                <a class="text-white px-1" href="https://web.facebook.com/RangoElectronics">
                    <i class="fab fa-facebook-f"></i>
                </a>
                <a class="text-white px-1" href="">
                    <i class="fab fa-twitter"></i>
                </a>
                <a class="text-white px-1" href="">
                    <i class="fab fa-linkedin-in"></i>
                </a>
                <a class="text-white px-1" href="https://instagram.com/rangoelectronics?utm_source=qr&igshid=MzNlNGNkZWQ4Mg==">
                    <i class="fab fa-instagram"></i>
                </a>
                <a class="text-white px-1" href="">
                    <i class="fab fa-youtube"></i>
                </a>
            </div>
        </div>
    </div>

    <!-- Mobile View: Show Email and Number -->
    <div class="row d-block d-lg-none text-center py-2" style="background-color: maroon; color: white;">
        <div class="col-12">
            <div class="d-inline-flex align-items-center">
                <a class="text-white px-2" href="">
                    <i class="fa-solid fa-phone-volume"></i>
                </a>
                <span class="text-white px-1">+8801798-565001</span>
            </div>
        </div>
        <div class="col-12 mt-2">
            <div class="d-inline-flex align-items-center">
                <a class="text-white px-2" href="">
                    <i class="fa-solid fa-envelope"></i>
                </a>
                <span class="text-white px-2">electronics.rango@gmail.com</span>
            </div>
        </div>
    </div>
</div>
<div class="dividerTop">
</div>
<?php /**PATH /Users/rahmanabir/Desktop/Project/Rango/resources/views/front/includes/topbarOne.blade.php ENDPATH**/ ?>