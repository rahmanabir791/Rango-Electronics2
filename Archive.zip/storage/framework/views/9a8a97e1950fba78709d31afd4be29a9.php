<?php $__env->startSection('title'); ?>
    Manage All Slide
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
    <div class="col-lg-12 grid-margin stretch-card">


                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Add Slider Data</h4>
                            <form action="<?php echo e(route('newSlider')); ?>" method="post" class="form-inline" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <input type="text" name="sliderStext" class="form-control mb-2 mr-sm-2"  placeholder="Upper Line / Small Line / offer text">

                                <div class="input-group mb-2 mr-sm-2">

                                    <input type="text" name="sliderBtext" class="form-control" id="inlineFormInputGroupUsername2" placeholder="Below Line | Name ">
                                </div>
                                <div class="input-group mb-2 mr-sm-2">

                                    <input type="file" accept="image/*" name="slidImage" class="form-control" id="inlineFormInputGroupUsername2" placeholder="Slider Image" required>
                                </div>
                                <button type="submit" class="btn btn-gradient-primary mb-2">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
      
            <!-- content-wrapper ends -->


        <div class="card">
            <div class="card-body">
                <h4 class="card-title">All Slider Details</h4>

                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>SL No.</th>
                        <th>Slider Small Text</th>
                        <th>Slider Big Text</th>
                        <th>Slider Image</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $SliderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SliderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($SliderDetail->sliderStext); ?></td>
                        <td><?php echo e($SliderDetail->sliderBtext); ?></td>
                        <td>
                            <img src="<?php echo e(asset($SliderDetail->slidImage)); ?>" alt="" style="height: 100px; width: 100px">
                        </td>
                        <td>
                            <a href="<?php echo e(route('delete-slider', ['id' => $SliderDetail->id])); ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmanabir/Desktop/Rango All Work/Rango/resources/views/back/pages/slider/manageSlide.blade.php ENDPATH**/ ?>