<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<?php echo $__env->make('front.pages.navtest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Featured Start -->
    <div  class="container-fluid pt-5" style=" padding: 0; " >
        <div class="row ">
            <div class="col-lg-4" >
                    <a href="#"><img class="mb-0 ml-2" src="<?php echo e(asset('/')); ?>assets/front-asset/img/banner-1.jpg" style=" margin-left: 2px; height: 303px;" width="405;" alt="image; " ></a>
            </div>
                <div class="col-lg-4 ">
                    <div class="row">
                            <a href="#"><img class="mb-2 ml-2" src="<?php echo e(asset('/')); ?>assets/front-asset/img/banner-2.jpg" style="height: 148px;" width="405px;" alt="image"></a>
                            <a href="#"><img class="mb-2 ml-2" src="<?php echo e(asset('/')); ?>assets/front-asset/img/banner-3.jpg" style="height: 148px;" width="405px;" alt="image"></a>
                    </div>
                </div>
                <div class="col-lg-4 ">
                    <div class="row">
                        <a href="#"><img class="mb-2 ml-0 " src="<?php echo e(asset('/')); ?>assets/front-asset/img/banner-5.jpg" style="height: 148px;" width="405px;" alt="image"></a>
                        <a href="#"><img class="mb-2 ml-0" src="<?php echo e(asset('/')); ?>assets/front-asset/img/banner-3.jpg" style="height: 148px;" width="405px;" alt="image"></a>

                    </div>
                  </div>
            </div>
        </div>
    </div>
    <!-- Featured End -->



<p class="slider-name text-dark font-weight-bold " >Special Offer Products</p>
<span class="divider"></span>
<p class="view-all"><a href="#">View All ></a></p>
<!--slider row-1 for Special Offer Products -->
<div class="owl-carousel  image-slider">

    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($product->special_offer == 1): ?>
        <div class="card product-item border-0 mb-4">
            <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                <a href="#"><img src="<?php echo e(asset($product->image)); ?>" style="height: 300px;" width="150px;" alt="image"></a>
            </div>
            <div class="card-body border-left border-right text-center p-0 pt-4 ">
                <h6 class="text-truncate mb-3"><?php echo e($product->productName); ?></h6>
                <div class="d-flex justify-content-center">
                    <h6>৳<?php echo e($product->O_price); ?></h6><h6 class="text-muted ml-2"><del>৳<?php echo e($product->MRP_price); ?></del></h6>
                </div>
                <div class="card-footer d-flex justify-content-between bg-light border">
                    <a href="" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary "></i>
                        View Detail</a>
                    <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                        <input type="hidden" value="<?php echo e($product->productName); ?>" name="name">
                        <input type="hidden" value="<?php echo e(asset($product->image)); ?>"  name="image">
                        <input type="hidden" value="<?php echo e($product->O_price); ?>" name="price">
                        <input type="hidden" value="1" name="quantity">
                        <button type="submit"  class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</button>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>



<p class="slider-name text-dark font-weight-bold " >All Products</p>
<span class="divider"></span>
<p class="view-all"><a href="#">View All ></a></p>
<!--slider row-1 for Special Offer Products -->
<div class="owl-carousel  image-slider">
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card product-item border-0 mb-4">
        <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
            <a href="#"><img src="<?php echo e(asset($product->image)); ?>" style="height: 300px;" width="150px;" alt="image"></a>
        </div>
        <div class="card-body border-left border-right text-center p-0 pt-4 ">
            <h6 class="text-truncate mb-3"><?php echo e($product->productName); ?></h6>
            <div class="d-flex justify-content-center">
                <h6>৳<?php echo e($product->O_price); ?></h6><h6 class="text-muted ml-2"><del>৳<?php echo e($product->MRP_price); ?></del></h6>
            </div>
            <div class="card-footer d-flex justify-content-between bg-light border">
                <a href="" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary "></i>
                    View Detail</a>
                <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                    <input type="hidden" value="<?php echo e($product->productName); ?>" name="name">
                    <input type="hidden" value="<?php echo e(asset($product->image)); ?>"  name="image">
                    <input type="hidden" value="<?php echo e($product->O_price); ?>" name="price">
                    <input type="hidden" value="1" name="quantity">
                    <button type="submit"  class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</button>
                </form>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>



<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<!--slider row-2-->
<p class="slider-name text-dark font-weight-bold"><?php echo e($category->CategoryName); ?></p>
<span class="divider"></span>
<p class="view-all"><a href="#">View All ></a></p>
<div class="owl-carousel  image-slider">

    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Service$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($category->id == $product->category_id): ?>
        <div class="card product-item border-0 mb-4">
            <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                <a href="#"><img src="<?php echo e(asset($product->image)); ?>" style="height: 300px;" width="150px;" alt="image"></a>
            </div>
            <div class="card-body border-left border-right text-center p-0 pt-4 ">
                <h6 class="text-truncate mb-3"><?php echo e($product->productName); ?></h6>
                <div class="d-flex justify-content-center">
                    <h6>৳<?php echo e($product->O_price); ?></h6><h6 class="text-muted ml-2"><del>৳<?php echo e($product->MRP_price); ?></del></h6>
                </div>
                <div class="card-footer d-flex justify-content-between bg-light border">
                    <a href="" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary "></i>
                        View Detail</a>
                    <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                        <input type="hidden" value="<?php echo e($product->productName); ?>" name="name">
                        <input type="hidden" value="<?php echo e(asset($product->image)); ?>"  name="image">
                        <input type="hidden" value="<?php echo e($product->O_price); ?>" name="price">
                        <input type="hidden" value="1" name="quantity">
                        <button type="submit"  class="btn btn-sm text-dark p-0"><i class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart</button>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<h1 class="text-center bg-danger">Brands</h1>
<!--last row-->
<div class="owl-carousel owl-theme">

    <?php
        $sameBrandIds = [];
        $brandImages = [];

        foreach ($brands as $brand) {
            if (!in_array($brand->BrandName, array_keys($sameBrandIds))) {
                $sameBrandIds[$brand->BrandName] = [$brand->id];
                $brandImages[$brand->BrandName] = $brand->BrandImage;
            } else {
                $sameBrandIds[$brand->BrandName][] = $brand->id;
            }
        }
    ?>

    <?php $__currentLoopData = $sameBrandIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brandName => $ids): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card product-item border-0 mb-4">
            <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                <p><?php echo e($brandName); ?></p>
                <a href="<?php echo e(route('brand.all.products', ['ids' => implode(',', $ids)])); ?>">
                    <img src="<?php echo e(asset($brandImages[$brandName])); ?>" style="height: 150px;" width="150px;" alt="Brand image">
                </a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<!--script for last row-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmanabir/Desktop/Rango All Work/Rango/resources/views/front/pages/home.blade.php ENDPATH**/ ?>
