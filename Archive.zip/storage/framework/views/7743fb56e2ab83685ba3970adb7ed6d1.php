<!DOCTYPE html>
    <html lang="en,bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rango Electronics - Invoice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .invoice {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }
        .invoice-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .invoice-title {
            font-size: 32px;
            margin-bottom: 5px;
            color: #333;
        }
        .invoice-details p {
            margin: 5px 0;
            color: #555;
        }
        .invoice-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .invoice-table th, .invoice-table td {
            padding: 10px;
            border-bottom: 1px solid #ccc;
        }
        .invoice-table th {
            background-color: #f2f2f2;
            color: #333;
            font-weight: bold;
        }
        .invoice-total {
            text-align: right;
            font-weight: bold;
        }
        .thank-you {
            text-align: center;
            margin-top: 20px;
            color: #555;
        }
    </style>
</head>
<body>
<div class="invoice">
    <div class="invoice-header">
        <h1 class="invoice-title">Rango Electronics Invoice</h1>
        <p>Your Trusted Electronics Store</p>
    </div>
    <div class="invoice-details">
        <p><strong>Invoice Number:</strong> <?php echo $invoiceNumber; ?></p>
        <p><strong>Date:</strong> <?php echo $currentDate; ?></p>
        <p><strong>Billed To:</strong></p>
        <p><?php echo $name; ?></p>
        <p><?php echo $address; ?></p>
        <p><?php echo $city; ?>, <?php echo $zip; ?> </p>
    </div>
    <table class="invoice-table">
        <thead>
        <tr>
            <th>Description</th>
            <th>Quantity</th>
            <th>Unit Price</th>
            <th>Total</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $productData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($product['name']); ?></td>
                <td><?php echo e($product['quantity']); ?></td>
                <td>Tk: <?php echo e($product['price']); ?></td>
                <td>Tk: <?php echo e($product['quantity'] * $product['price']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
        <tr>
            <td colspan="3" class="invoice-total">Total:</td>
            <td>Tk: <?php echo e($totalAmount); ?></td>
        </tr>
        <?php if($p_status == 0): ?>
            <tr>
                <td colspan="3" class="invoice-total">Advance Payment:</td>
                <td>Tk: <?php echo $A_payment; ?></td>
            </tr>
            <tr>
                <td colspan="3" class="invoice-total">Remain Total Amount:</td>
                <td>Tk: <?php echo $remainAmount; ?></td>
            </tr>
            <tr>
                <td colspan="4">Payment Method: <?php echo e($f_service); ?></td>
            </tr>
            <tr>
                <td colspan="4">Transaction Number: <?php echo e($Transaction_num); ?></td>
            </tr>
        <?php endif; ?>
        </tfoot>
    </table>
    <div class="thank-you">
        <p>Thank you for choosing Rango Electronics!</p>
    </div>
</div>
</body>
</html>

<?php /**PATH /Users/rahmanabir/Desktop/Rango All Work/Rango/resources/views/back/forClient/rangoInvoice.blade.php ENDPATH**/ ?>