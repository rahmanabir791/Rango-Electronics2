<?php $__env->startSection('title'); ?>
    Edit Brand
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="main-panel">

        <div class="content-wrapper">

            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Edit Brand</h4>
                        <p class="card-description">Select the category name, brand name, and upload an image for the brand</p>
                        <form method="post" action="<?php echo e(route('update-Brand', ['id' => $Brands->id])); ?>" class="form-inline" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <label class="sr-only" for="categoryName">Category Name</label>
                            <div class="form-group">
                                <label for="category_id">Select Product Category</label>
                                <select class="form-control" name="category_id" id="category_id" required>
                                    <option disabled>Select an option</option>
                                    <?php $__currentLoopData = $allCategorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>" <?php echo e($Brands->category_id == $category->id ? 'selected' : ''); ?>>
                                            <?php echo e($category->CategoryName); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>



                            <label class="sr-only" for="brandName">Brand Name</label>
                            <input type="text" name="BrandName" value="<?php echo e($Brands->BrandName); ?>" class="form-control mb-2 mr-sm-2" id="brandName" placeholder="Brand Name" required>


                            <label class="sr-only" for="brandName">Brand Image</label>
                            <img src="<?php echo e(asset($Brands->BrandImage)); ?>" alt="" style="height: 100px; width: 100px;">

                            <div class="input-group mb-2 mr-sm-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">Brand Image</div>
                                </div>
                                <input type="file" name="BrandImage" class="form-control" id="brandImage" accept="image/*" >
                            </div>
                            <?php if($errors->has('BrandImage')): ?>
                                <div class="alert alert-danger"><?php echo e($errors->first('BrandImage')); ?></div>
                            <?php endif; ?>

                            <button type="submit" class="btn btn-gradient-primary mb-2">Add brands to categories</button>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmanabir/Desktop/Rango All Work/Rango/resources/views/back/pages/brands/edit_brands.blade.php ENDPATH**/ ?>