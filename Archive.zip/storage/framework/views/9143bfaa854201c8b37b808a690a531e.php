
<!-- Back to Top -->
<a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(asset('/')); ?>assets/front-asset/img/productimglib/easing/easing.min.js"></script>
<script src="<?php echo e(asset('/')); ?>assets/front-asset/img/productimglib/owlcarousel/owl.carousel.min.js"></script>

<!-- Contact Javascript File -->
<script src="<?php echo e(asset('/')); ?>assets/front-asset/img/productimgmail/jqBootstrapValidation.min.js"></script>
<script src="<?php echo e(asset('/')); ?>assets/front-asset/img/productimgmail/contact.js"></script>

<!-- Template Javascript -->
<script src="<?php echo e(asset('/')); ?>assets/front-asset/img/productimgjs/main.js"></script>



</body>

</html>
<?php /**PATH /Users/rahmanabir/Desktop/Rango/resources/views/home/includes/script.blade.php ENDPATH**/ ?>