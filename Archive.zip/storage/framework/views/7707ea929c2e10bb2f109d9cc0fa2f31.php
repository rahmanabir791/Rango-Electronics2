<?php $__env->startSection('title'); ?>
    home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<?php echo $__env->make('home.pages.navCategories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Featured Start -->
    <div class="container-fluid pt-5">
        <div class="row px-xl-5 pb-3">
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="d-flex align-items-center border mb-4" style="padding: 30px;">
                    <h1 class="fa fa-check text-primary m-0 mr-3"></h1>
                    <h5 class="font-weight-semi-bold m-0">Quality Product</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="d-flex align-items-center border mb-4" style="padding: 30px;">
                    <h1 class="fa fa-shipping-fast text-primary m-0 mr-2"></h1>
                    <h5 class="font-weight-semi-bold m-0"> Shipping</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="d-flex align-items-center border mb-4" style="padding: 30px;">
                    <h1 class="fas fa-exchange-alt text-primary m-0 mr-3"></h1>
                    <h5 class="font-weight-semi-bold m-0">7-Day Return</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-12 pb-1">
                <div class="d-flex align-items-center border mb-4" style="padding: 30px;">
                    <h1 class="fa fa-phone-volume text-primary m-0 mr-3"></h1>
                    <h5 class="font-weight-semi-bold m-0">24/7 Support</h5>
                </div>
            </div>
        </div>
    </div>
    <!-- Featured End -->


<div class="container text-center">
    <div class="row">
        <div class="col-md-3 mt-1">
            <div class="card">
<h1>Abir</h1>
            </div>
        </div>


        <div class="col-md-3">
            <div class="card">
                <h1>Abir</h1>
            </div>
        </div>


        <div class="col-md-3">
            <div class="card">
                <h1>Abir</h1>
            </div>
        </div>


        <div class="col-md-3">
            <div class="card">
                <h1>Abir</h1>
            </div>
        </div>


        <div class="col-md-3 mt-1">
            <div class="card">
                <h1>Abir</h1>
            </div>
        </div>


        <div class="col-md-3">
            <div class="card">
                <h1>Abir</h1>
            </div>
        </div>


        <div class="col-md-3">
            <div class="card">
                <h1>Abir</h1>
            </div>
        </div>


        <div class="col-md-3">
            <div class="card">
                <h1>Abir</h1>
            </div>
        </div>


        <div class="col-md-3">
            <div class="card">
                <h1>Abir</h1>
            </div>
        </div>


        <div class="col-md-3">
            <div class="card">
                <h1>Abir</h1>
            </div>
        </div>
    </div>
</div>

    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <style>
        /* Styles for the card layout */
        .swiper-container {
            width: 100%;
            margin: 0 auto;

        }

        .swiper-slide {
            text-align: center;
            padding: 20px;
        }

        .swiper-slide img {
            max-width: 100%;
            height: auto;
        }
    </style>

<div class="container-fluid pt-5">
    <div class="swiper-container">
        <div class="swiper-wrapper">
            <!-- Card 1 -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image1.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 1</h5>
                </div>
            </div>
            <!-- Card 2 -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image2.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 2</h5>
                </div>
            </div>
            <!-- Card 3 -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image3.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 3</h5>
                </div>
            </div>
            <!-- Card 4 -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <!-- Add more cards as needed -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>


        </div>
        <!-- Add navigation buttons -->

    </div>
</div>

<div class="container-fluid pt-5">
    <div class="swiper-container">
        <div class="swiper-wrapper">
            <!-- Card 1 -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image1.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 1</h5>
                </div>
            </div>
            <!-- Card 2 -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image2.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 2</h5>
                </div>
            </div>
            <!-- Card 3 -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image3.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 3</h5>
                </div>
            </div>
            <!-- Card 4 -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <!-- Add more cards as needed -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>


        </div>
        <!-- Add navigation buttons -->

    </div>
</div>

<div class="container-fluid pt-5">
    <div class="swiper-container">
        <div class="swiper-wrapper">
            <!-- Card 1 -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image1.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 1</h5>
                </div>
            </div>
            <!-- Card 2 -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image2.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 2</h5>
                </div>
            </div>
            <!-- Card 3 -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image3.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 3</h5>
                </div>
            </div>
            <!-- Card 4 -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <!-- Add more cards as needed -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>


        </div>
        <!-- Add navigation buttons -->
    
    </div>
</div>

<div class="container-fluid pt-5">
    <div class="swiper-container">
        <div class="swiper-wrapper">
            <!-- Card 1 -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image1.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 1</h5>
                </div>
            </div>
            <!-- Card 2 -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image2.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 2</h5>
                </div>
            </div>
            <!-- Card 3 -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image3.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 3</h5>
                </div>
            </div>
            <!-- Card 4 -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <!-- Add more cards as needed -->
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>
            <div class="swiper-slide">
                <div class="cat-item d-flex flex-column border mb-4 text-center">
                    <a href="" class="cat-img position-relative overflow-hidden mb-3">
                        <img class="img-fluid" src="image4.jpg" alt="">
                    </a>
                    <h5 class="font-weight-semi-bold m-0">Product 4</h5>
                </div>
            </div>


        </div>
        <!-- Add navigation buttons -->

    </div>
</div>

<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script>
    var swiper = new Swiper('.swiper-container', {
        slidesPerView: 4,  // Display up to 4 cards in one row
        slidesPerGroup: 4, // Move cards as a group of 4
        spaceBetween: 20,
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });
</script>






























































































































































































































































































































































































<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmanabir/Desktop/Rango/resources/views/home/pages/home.blade.php ENDPATH**/ ?>