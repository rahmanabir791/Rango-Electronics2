<?php $__env->startSection('title'); ?>
    Service Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <!-- Page Header Start -->
    <?php echo $__env->make('front.includes.navCategoryForOthers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <hr style=" background-color: maroon">
    <div class="container-fluid py-3" style="color: black">
        <div class="row px-xl-5">
            <div class="col-lg-5 pb-5">
                <div id="product-carousel" class="carousel slide" data-ride="carousel"   >
                    <div class="carousel-inner border" style="border-color: maroon;" >
                        <div class="carousel-item active">
                            <img class="w-100 h-100" src="<?php echo e(asset($service->ServiceImage)); ?>" alt="Image">
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-7 pb-5">
                <h3 class="font-weight-semi-bold"><?php echo e($service->ServiceName); ?></h3>
                <br>
                <h5 class="font-weight-semi-bold mb-4" style="color: maroon;">Offer Price: ৳<?php echo e(number_format($service->ServicePrice)); ?> </h5>

                <p class="mb-4 text-center"><?php echo $service->description; ?></p>


                <div class="d-flex align-items-center mb-4 pt-2">
                    <?php if(count($cartItems) === 0): ?>
                        <!-- Display the "Add to Cart" section for products not in the cart -->
                        <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="input-group quantity mr-3" style="width: 130px;">
                                <div class="input-group-prepend">
                                    <button class="btn btn-maroon btn-minus" type="button">
                                        <i class="fa fa-minus" style="color: gold;"></i>
                                    </button>
                                </div>
                                <input type="number" class="form-control bg-secondary text-center" name="quantity" value="0">
                                <div class="input-group-append">
                                    <button class="btn btn-maroon btn-plus" type="button">
                                        <i class="fa fa-plus" style="color: gold;"></i>
                                    </button>
                                </div>
                            </div>
                            <input type="hidden" value="<?php echo e($service->id); ?>" name="id">
                            <input type="hidden" value="<?php echo e($service->ServiceName); ?>" name="name">
                            <input type="hidden" value="<?php echo e(asset($service->ServiceImage)); ?>" name="image">
                            <input type="hidden" value="<?php echo e($service->ServicePrice); ?>" name="price">
                            <button type="submit" class="btn btn-maroon px-3" style="color: gold; background-color: maroon;"><i class="fa fa-shopping-cart mr-1"></i> Add To Cart</button>
                        </form>
                    <?php endif; ?>

                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Display the cart items and their respective forms -->
                        <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="input-group quantity mr-3" style="width: 130px;">
                                <div class="input-group-prepend">
                                    <button class="btn btn-maroon btn-minus" type="button">
                                        <i class="fa fa-minus" style="color: gold;"></i>
                                    </button>
                                </div>
                                <input type="number" class="form-control bg-secondary text-center" name="quantity" value="0">
                                <div class="input-group-append">
                                    <button class="btn btn-maroon btn-plus" type="button">
                                        <i class="fa fa-plus" style="color: gold;"></i>
                                    </button>
                                </div>
                            </div>
                            <input type="hidden" value="<?php echo e($service->id); ?>" name="id">
                            <input type="hidden" value="<?php echo e($service->ServiceName); ?>" name="name">
                            <input type="hidden" value="<?php echo e(asset($service->ServiceImage)); ?>" name="image">
                            <input type="hidden" value="<?php echo e($service->ServicePrice); ?>" name="price">
                            <button type="submit" class="btn btn-maroon px-3" style="color: gold; background-color: maroon"><i class="fa fa-shopping-cart mr-1"></i> Add To Cart</button>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="d-flex pt-2">
                    <p class="text-dark font-weight-medium mb-0 mr-2">Share on:</p>
                    <div class="d-inline-flex">
                        <a class="text-dark px-2" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(request()->fullUrl())); ?>">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a class="text-dark px-2" href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode(request()->fullUrl())); ?>">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a class="text-dark px-2" href="https://www.linkedin.com/shareArticle?url=<?php echo e(urlencode(request()->fullUrl())); ?>">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        <a class="text-dark px-2" href="http://pinterest.com/pin/create/button/?url=<?php echo e(urlencode(request()->fullUrl())); ?>">
                            <i class="fab fa-pinterest"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Rest of your code remains the same -->
    <div class="row px-xl-5">
        <div class="col">
            <div class="nav nav-tabs justify-content-center border-secondary mb-4">
                <a class="nav-item nav-link active" data-toggle="tab" href="#tab-pane-1">Specifications</a>
            </div>
            <div class="tab-content text-center" >
                <div class="tab-pane fade show active " style="color: black;" id="tab-pane-1">
                    <h4 class="mb-3">Product Specifications</h4>
                    <p class="text-center"><?php echo $service->specification; ?></p>
                </div>

            </div>
        </div>
    </div>

    <!-- Shop Detail End -->

    <!-- Products Start -->
    <div class="container-fluid py-5">
        <div class="text-center mb-4">
            <h2 class="section-title px-5"><span class="px-2">You May know Other Products</span></h2>
        </div>
        <div class="row px-xl-5">
            <div class="col">
                <div class="owl-carousel related-carousel image-slider">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card product-item border-0">
                            <div class="card-header product-img position-relative overflow-hidden bg-transparent border p-0">
                                <img class="img-fluid w-100" src="<?php echo e(asset($product->image)); ?>"  style="height: 300px;  width: 150px;" alt="">
                            </div>
                            <div class="card-body border-left border-right text-center p-0 pt-4 pb-3">
                                <h6 class="text-truncate mb-3"><?php echo e($product->productName); ?></h6>
                                <div class="d-flex justify-content-center">
                                    <h6>৳<?php echo e(number_format($product->O_price)); ?></h6><h6 class="text-muted ml-2"><del>৳<?php echo e(number_format($product->MRP_price)); ?>

                                        </del></h6>
                                </div>
                            </div>
                            <div class="card-footer d-flex justify-content-between bg-light border">
                                <a href="<?php echo e(route('productDetail' , [ 'id' => $product->id ])); ?>" class="btn btn-sm text-dark p-0"><i class="fas fa-eye text-primary "></i>View Detail</a>
                                <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                                    <input type="hidden" value="<?php echo e($product->productName); ?>" name="name">
                                    <input type="hidden" value="<?php echo e(asset($product->image)); ?>" name="image">
                                    <input type="hidden" value="<?php echo e($product->O_price); ?>" name="price">
                                    <input type="hidden" value="1" name="quantity">
                                    <button type="submit" class="btn btn-sm text-dark p-0"><i
                                            class="fas fa-shopping-cart text-primary mr-1"></i>Add To Cart
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Products End -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const minusButtons = document.querySelectorAll(".btn-minus");
            const plusButtons = document.querySelectorAll(".btn-plus");
            const quantityInputs = document.querySelectorAll(".quantity input[name='quantity']");

            minusButtons.forEach((button, index) => {
                button.addEventListener("click", function () {
                    if (quantityInputs[index].value > 0) {
                        quantityInputs[index].value--;
                    }
                });
            });

            plusButtons.forEach((button, index) => {
                button.addEventListener("click", function () {
                    quantityInputs[index].value++;
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmanabir/Desktop/Rango All Work/Rango/resources/views/front/pages/details_pages/installation_Details.blade.php ENDPATH**/ ?>